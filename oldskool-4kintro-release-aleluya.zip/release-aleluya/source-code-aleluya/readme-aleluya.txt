Hallelujah

compile with:

cl65 -O aleluya.c
Download cc65 @ https://www.cc65.org
remember to set $CC65_HOME , and add $CC65_HOME/bin to $PATH

Run with https://vice-emu.sourceforge.io/
In settings, put the folder with the compiled file in Peripheral Devices, Drive 
and make sure to set IEC (OpenCBM)

